#include <stdio.h>
#include "uart_thread0.h"
#include "cli.h"

#define  messageSize  64+2 //add CR/LF
#define  CR     0x0D
#define  LF     0x0C
#define  BS     0x08

#define OUTPUT_BUFFER_SIZE 64

uint8_t RxMessage[messageSize];
uint8_t myChar[1] = {0};

void clearBuffer (char *myBuf, uint8_t count);

void printThis (char *str)
{
  int size = strlen(str);
  g_sf_comms0.p_api->write(g_sf_comms0.p_ctrl, str, size, 5);
}

// Redefine puts to handle printf output
int __write(int file, char *buffer, int count)
{ 
    // Write String to UART
    for (int i = 0; i < count; i++)
    {
        // Start Transmission
        ssp_err_t err = g_sf_comms0.p_api->write(g_sf_comms0.p_ctrl, (uint8_t *)(buffer + i), 1, 2);
        if (err != SSP_SUCCESS)
        {
            break;
        }
    }
    //setvbuf(file, NULL, _IONBF, OUTPUT_BUFFER_SIZE);
    return 0;
}

/* UART Thread entry function */
//char str1[66] = "";
void uart_thread0_entry(void)
{
    g_sf_comms0.p_api->open(g_sf_comms0.p_ctrl, g_sf_comms0.p_cfg);

    uint8_t y = 0;
    while(1)
    {
        while ((*myChar != CR) && (y < messageSize-2))
        {
            myChar[0] = 0;
            ssp_err_t err = g_sf_comms0.p_api->read(g_sf_comms0.p_ctrl, myChar, 1, 2);
            if (err == SSP_SUCCESS)
            {
                if (myChar[0] == BS) // accomodate for back space.
                {
                    if (y > 0)
                    {
                    RxMessage[--y] = 0;
                    }
                }
                else
                {
                  RxMessage[y++] = myChar[0];
                }
            }
            tx_thread_sleep(1);
        }
        //RxMessage[y] = LF;
        cli_engine((char *)RxMessage);
        clearBuffer(RxMessage, sizeof(RxMessage));
        y = 0;
        myChar[0] = 0;
    } 
}
void clearBuffer (char *myBuf, uint8_t count)
{
    for (int i = 0; i < count; i++)
    {
        myBuf[i] = 0;
    }
}
