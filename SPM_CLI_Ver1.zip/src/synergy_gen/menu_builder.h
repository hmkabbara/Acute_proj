/*
 * menu_builder.h
 *
 *  Created on: December, 17, 2023
 *      Author: hazem
 */

#ifndef MENU_BUILDER_H_
#define MENU_BUILDER_H_


/*
 * Public directories that applications can register with.
 * Enable define for these root directories.  Once defined,
 * apps can register in this directory structure.  If not,
 * applications register to the root directory.
 */
#define CLI_ROOT_DIRS     ( 1 )

#define MIN_VAL					-40.00
#define MAX_VAL  				99.00

char menu_build (void);

#endif /* MENU_BUILDER_H_ */
